import { createMiddlewareClient } from "@supabase/auth-helpers-nextjs"
import { NextResponse } from "next/server"
import type { NextRequest } from "next/server"

export async function middleware(req: NextRequest) {
  const res = NextResponse.next()
  const supabase = createMiddlewareClient({ req, res })

  const {
    data: { session },
  } = await supabase.auth.getSession()

  // URLからバイパスパラメータを確認
  const { searchParams } = new URL(req.url)
  const bypass = searchParams.get("bypass") === "true"

  // バイパスモードが有効な場合は認証をスキップ
  if (bypass) {
    console.log("Auth bypass enabled")
    return res
  }

  // ダッシュボードとアドミンページの保護
  if ((req.nextUrl.pathname.startsWith("/dashboard") || req.nextUrl.pathname.startsWith("/admin")) && !session) {
    return NextResponse.redirect(new URL("/", req.url))
  }

  // ログイン済みユーザーがログインページにアクセスした場合はダッシュボードにリダイレクト
  if (req.nextUrl.pathname === "/" && session) {
    return NextResponse.redirect(new URL("/dashboard", req.url))
  }

  return res
}

export const config = {
  matcher: ["/", "/dashboard/:path*", "/admin/:path*"],
}

